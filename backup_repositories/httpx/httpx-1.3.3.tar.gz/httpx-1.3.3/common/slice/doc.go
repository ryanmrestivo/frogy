// Package slice contains a set of utilities to deal with slices
package slice
