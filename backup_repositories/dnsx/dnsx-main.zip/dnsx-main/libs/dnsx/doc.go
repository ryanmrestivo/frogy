// Package dnsx contains the library logic
package dnsx
