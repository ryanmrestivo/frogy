package common

import "errors"

var ErrOutOfScope = errors.New("out of scope")
