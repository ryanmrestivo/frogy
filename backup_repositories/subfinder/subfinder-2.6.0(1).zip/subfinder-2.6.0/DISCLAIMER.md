## Disclaimer

Subfinder leverages multiple open APIs, it is developed for individuals to help them for research or internal work. If you wish to incorporate this tool into a commercial offering or purposes, you must agree to the Terms of the leveraged services:

- Bufferover:  https://tls.bufferover.run
- CommonCrawl: https://commoncrawl.org/terms-of-use/full
- certspotter: https://sslmate.com/terms
- dnsdumpster: https://hackertarget.com/terms
- Google Transparency: https://policies.google.com/terms
- Alienvault: https://www.alienvault.com/terms/website-terms-of-use07may2018

---

You expressly understand and agree that Subfinder (creators and contributors) shall not be liable for any damages or losses resulting from your use of this tool or third-party products that use it.

Creators aren't in charge of any and have/has no responsibility for any kind of:

- Unlawful or illegal use of the tool.
- Legal or Law infringement (acted in any country, state, municipality, place) by third parties and users.
- Act against ethical and / or human moral, ethic, and peoples and cultures of the world.
- Malicious act, capable of causing damage to third parties, promoted or distributed by third parties or the user through this tool.


### Contact

Please contact at contact@projectdiscovery.io for any questions.
